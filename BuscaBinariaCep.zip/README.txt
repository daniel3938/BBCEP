1. Extrair a pasta contendo o projeto.
2. Verificar se o arquivo "cep_ordenado.dat" se encontra na pasta "BuscaBinariaCep\src".
3. Utilizando o Terminal / Prompt de Comando, mudar o diret�rio para a pasta "BuscaBinariaCep\src".
4. Compilar o arquivo Main.java utilizando o comando "javac Main.java".
5. Utilizar o comando "java Main [CEP]" para utilizar a busca bin�ria, onde [CEP] � o CEP que deseja buscar.
