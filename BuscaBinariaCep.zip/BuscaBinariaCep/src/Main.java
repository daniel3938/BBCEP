import java.io.RandomAccessFile;

public class Main {
 
    public static void main(String args[]) throws Exception 
    {
       if (args.length != 1) 
        {     
        	System.err.println("Erro na chamada do comando.");
            System.err.println("Uso: java Main [CEP].");
            System.exit(1);
        } 
    	RandomAccessFile f = new RandomAccessFile("cep_ordenado.dat", "r");
        Endereco e = new Endereco();
        long tamanho = (f.length()/300);
        int cepa,cepb, n = 0;
        String meioCEP;
        boolean check=false;
       
        System.out.println("Numero de CEPs registrados do arquivo: ");
        System.out.println(tamanho);
        System.out.println("CEP a ser buscado: ");
        String ucep = args[0];
        System.out.println(ucep);
        
        if (ucep.length() == 8) 
        {
        	cepa = Integer.parseInt(ucep);
                
        	f.seek(0);
        	long primeiro = f.getFilePointer();
        
        	f.seek((tamanho-1)*300);
        	long ultimo = f.getFilePointer();
        
        	f.seek((((ultimo/300)-(primeiro/300))/2)*300);
        	long meio = f.getFilePointer();
        
        	do 
        	{
        		f.seek(meio);
        		e.leEndereco(f);
        		meioCEP = e.getCep();
        		
        		cepb = Integer.parseInt(meioCEP);
        		if (cepa == cepb) 
        		{
        			f.seek(meio);
        			e.leEndereco(f);
        			System.out.println("Logradouro: ");
        			System.out.println(e.getLogradouro());
        			System.out.println("Bairro: ");
        			System.out.println(e.getBairro());
        			System.out.println("Cidade: ");
        			System.out.println(e.getCidade());
        			System.out.println("Estado: ");
        			System.out.println(e.getEstado());
        			System.out.println("Sigla: ");
        			System.out.println(e.getSigla());
        			check = true;
        			break;
        		}
        		if (cepa < cepb)
        			ultimo = meio-300;
        		else if (cepa > cepb)
        			primeiro = meio+300;
        		
        		meio = (((primeiro+ultimo)/300)/2)*300;
        		n = n+1;
        	} while (primeiro <= ultimo);
        	
        	if (check == false)
        	{
        		System.err.println("CEP Invalido.");
        		System.exit(1);
        	}
        	
        	System.out.println("Numero de vezes que passou pelo loop da Busca Binaria: ");
        	System.out.println(n);
        	//s.close();
        	f.close();
        }
        else
        {
        	System.err.println("CEP Invalido.");
        	System.exit(1);
        }
    }
}    